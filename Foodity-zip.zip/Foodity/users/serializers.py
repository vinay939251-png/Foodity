from rest_framework import serializers
from .models import User, Profile

class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = ['bio', 'profile_picture', 'location', 'birth_date']

class UserSerializer(serializers.ModelSerializer):
    profile = ProfileSerializer() # This nests the profile inside the user data

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'profile']