from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Profile

# This part allows you to edit the Profile (Bio/Picture) 
# right inside the same page as the User account.
class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    verbose_name_plural = 'Profile'

# We tell Django how to display our Custom User
class CustomUserAdmin(UserAdmin):
    inlines = (ProfileInline,)
    list_display = ('email', 'username', 'is_staff', 'is_active')
    list_filter = ('is_staff', 'is_active')
    search_fields = ('email', 'username')
    ordering = ('email',)

# Register the models so they show up in the browser
admin.site.register(User, CustomUserAdmin)