from rest_framework import serializers
from .models import DailyLog, MealEntry
from recipes.serializers import RecipeSerializer

class MealEntrySerializer(serializers.ModelSerializer):
    recipe_details = RecipeSerializer(source='recipe', read_only=True)

    class Meta:
        model = MealEntry
        fields = ['id', 'meal_type', 'calories', 'protein', 'carbs', 'fats', 'recipe', 'recipe_details']

class DailyLogSerializer(serializers.ModelSerializer):
    meal_entries = MealEntrySerializer(many=True, read_only=True)

    class Meta:
        model = DailyLog
        fields = ['id', 'date', 'water_intake', 'weight', 'meal_entries']